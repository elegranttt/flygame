#### INITIALIZATION
import pygame # Import Pygame
import random # For the random snail spawns
from sys import exit # So that we can exit on command

### INITIALIZE
pygame.init() # Initialize Pygame
screen = pygame.display.set_mode((800, 400)) # Display surface
pygame.display.set_caption("The Fly") # Window title
clock = pygame.time.Clock() # Clock for framerate controls
font = pygame.font.Font("font/Pixeltype.ttf", 50) # Set text font
music = pygame.mixer.Sound("audio/music.wav") # Import bg music
music.play(loops = -1) # Play background music with infinite loops
music.set_volume(0.2) # Set bg music volume
jumpSound = pygame.mixer.Sound("audio/jump.mp3") # Jump sound effect
jumpSound.set_volume(0.3)

### SURFACES AND RECTANGLES
## BACKGROUND
sky_s = pygame.image.load("graphics/Sky.png").convert() # Sky
ground_s = pygame.image.load("graphics/ground.png").convert() # Ground
## ENEMIES
# SNAIL
snail_s = pygame.image.load("graphics/snail/snail1.png").convert_alpha() # Snail surface
snail_rect = snail_s.get_rect(midbottom = (600, 300)) # Snail rectangle
# FLY
fly_s = pygame.image.load("graphics/Fly/Fly2.png").convert_alpha() # Fly surface
fly_rect = fly_s.get_rect(midbottom = (2500, 100)) # Fly rectangle
# FASTER FLY
fly2_s = pygame.image.load("graphics/Fly/Fly1.png").convert_alpha() # Faster fly surface
fly2_rect = fly2_s.get_rect(midbottom = (5000, 100)) # Faster fly rectangle

# PLAYER
player_s = pygame.image.load("graphics/Player/player_walk_1.png").convert_alpha() # Player surface
player_rect = player_s.get_rect(midbottom = (80,300)) # Player rectangle
player_gravity = 0 # Player gravity


### CONSTANTS
snail_speed = 4 # Original snail speed
fly_speed = 5 # Original fly speed
fly2_speed = 8 # Original faster fly speed
pts = 0 # Points as integer
points = str(pts) # Points converted to string
mouse_clicked = False # By default the mouse is not clicked
playing = False # Start at the title screen
startTime = 0 #  Set timer to 0 on start
menu = False # Menu is not open by default
dividedTime = 0 # Initialize the time in seconds

####end INIT

#### MAIN LOOP
while True:
    ### EVENT LOOP
    for event in pygame.event.get(): # Event loop
        if event.type == pygame.QUIT: # Check if asked to quit
            pygame.quit() # Quit Pygame
            exit() # Kill the process
        elif playing: # Check if playing
            if event.type == pygame.MOUSEBUTTONDOWN: #type: ignore
                mouse_clicked = True # Check if mouse button is clicked
            else:
                mouse_clicked = False
            if event.type == pygame.KEYDOWN: # KEYPRESSES
                if event.key == pygame.K_SPACE and player_rect.bottom >= 300 or event.key == pygame.K_UP and player_rect.bottom >= 300 or event.key == pygame.K_w and player_rect.bottom >= 300: # Jump
                    player_gravity = -22
                    pygame.mixer.Sound.play(jumpSound)
                if event.key == pygame.K_x:
                    playing = False
                if event.key == pygame.K_ESCAPE:
                    menu = True
        else:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_x:
                    pygame.quit()
                    exit()
                else:
                    playing = True
                    startTime = pygame.time.get_ticks()
            if event.type == pygame.MOUSEBUTTONDOWN:
                playing = True
                startTime = pygame.time.get_ticks()

    if menu:
        paused_s = font.render("Game paused.", False, ("Black")).convert()
        paused_rect = paused_s.get_rect(center = (398, 200))
        screen.blit(paused_s,(paused_rect))
        resume_s = font.render("Resume", False, ("Black")).convert()
        resume_rect = resume_s.get_rect(midleft = (10, 40))
        screen.blit(resume_s,(resume_rect))

        titleScreen_s = font.render("Title screen", False, (64,64,64)).convert()
        titleScreen_rect = titleScreen_s.get_rect(midleft = (9, 80))
        screen.blit(titleScreen_s,(titleScreen_rect))

        quit_s = font.render("Exit", False, ("Red")).convert()
        quit_rect = quit_s.get_rect(midleft = (9, 370))
        screen.blit(quit_s,(quit_rect))

        if titleScreen_rect.collidepoint(pygame.mouse.get_pos()):
            if mouse_clicked:
                menu = False
                playing = False
                mouse_clicked = False
        if quit_rect.collidepoint(pygame.mouse.get_pos()):
            if mouse_clicked:
                pygame.quit()
                exit()

        elif mouse_clicked:
            menu = False
            playing = True
            mouse_clicked = False


    elif playing:

        # TIME
        realTime = pygame.time.get_ticks() - startTime
        dividedTime = realTime/1000
        timeFromStart = f"Time: {dividedTime:.2f}"
        randomSnailSpawn = random.uniform(800.0,1159.0)

        # DRAW
        score_s = font.render(points, False, "Black").convert()
        score_rect = score_s.get_rect(center = (390, 100))
        screen.blit(sky_s,(0,0))
        screen.blit(ground_s,(0,300))
        screen.blit(score_s, (score_rect))
        time_s = font.render(timeFromStart, False, (64,64,64)).convert()
        time_rect = time_s.get_rect(center = (390, 140))
        screen.blit(time_s,(time_rect))

        # ENEMIES
        snail_rect.x -= snail_speed
        if snail_rect.right <= 0: snail_rect.left = randomSnailSpawn
        fly_rect.x -= fly_speed
        if fly_rect.right <= 0: playing = False
        fly2_rect.x -= fly2_speed
        if fly2_rect.right <= 0: fly2_rect.left = 6000
        screen.blit(snail_s,(snail_rect))
        screen.blit(fly_s, (fly_rect))
        screen.blit(fly2_s, (fly2_rect))

        # PLAYER
        player_gravity += 1
        player_rect.y += player_gravity
        if player_rect.bottom >= 300: player_rect.bottom = 300
        screen.blit(player_s, (player_rect))

        # DEATH
        if player_rect.colliderect(snail_rect) or player_rect.colliderect(fly_rect) or player_rect.colliderect(fly2_rect):
            print("You died!")
            playing = False

        # COLLIDERS
        if snail_rect.collidepoint(pygame.mouse.get_pos()):
            if mouse_clicked:
                snail_rect.left = randomSnailSpawn
                pts += 1
                points = str(pts)
                mouse_clicked = False

        if fly_rect.collidepoint(pygame.mouse.get_pos()):
            if mouse_clicked:
                fly_rect.left = 2000
                pts += 3
                points = str(pts)
                mouse_clicked = False

        if fly2_rect.collidepoint(pygame.mouse.get_pos()):
            if mouse_clicked:
                fly2_rect.left = 6000
                pts += 5
                points = str(pts)
                mouse_clicked = False
        if snail_speed <= 10: snail_speed += 0.0005
        if fly_speed <= 15: fly_speed += 0.0009
        if fly2_speed <= 20: fly2_speed += 0.001

    else:
        screen.fill("#c0e8ec")
        title_s = font.render("That Pesky Fly!", False, ("Black")).convert()
        title_rect = title_s.get_rect(center = (400, 250))
        screen.blit(title_s,(title_rect))
        screen.blit(player_s, (player_rect))
        pressText_s = font.render("Press any key to play.", False, (64,64,64)).convert()
        pressText_rect = pressText_s.get_rect(center = (400, 150))
        screen.blit(pressText_s,(pressText_rect))

        if dividedTime != 0: authorText_s = font.render(f"Time: {dividedTime:.2f}", False, (111,196,169)).convert()
        else: authorText_s = font.render("Made by Ekansh Rawal", False, (111,196,169)).convert()
        authorText_rect = authorText_s.get_rect(center = (400, 350))
        screen.blit(authorText_s,(authorText_rect))

        flyLogo = pygame.image.load("graphics/Fly/Fly1.png")
        screen.blit(flyLogo,(600,240))
        snail_rect.left = 800
        fly_rect.left = 2000
        fly2_rect.left = 6000
        pts = 0
        points = str(pts)
        snail_speed = 4
        fly_speed = 5
        fly2_speed = 8

    # Ticks and other end of loop stuff
    pygame.display.update()
    clock.tick(60)
